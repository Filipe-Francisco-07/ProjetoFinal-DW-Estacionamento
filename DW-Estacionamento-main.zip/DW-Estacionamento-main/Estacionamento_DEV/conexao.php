
<?php
define('DB_HOST', '127.0.0.1');
    define('DB_USER', 'root');
    define('DB_PASSWORD', '');
    define('DB_DB', 'estacionamento');
    define('DB_PORT', '3306');
    define('MYSQL_DSN', 'mysql:host='.DB_HOST.";dbname=".DB_DB.";charset=UTF8");
    
?>
